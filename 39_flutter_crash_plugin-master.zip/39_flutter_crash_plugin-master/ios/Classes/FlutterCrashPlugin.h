#import <Flutter/Flutter.h>

@interface FlutterCrashPlugin : NSObject<FlutterPlugin>
@end
